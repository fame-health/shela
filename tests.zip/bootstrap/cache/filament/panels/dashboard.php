<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.category-resource.pages.create-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\CreateCategory',
    'app.filament.resources.category-resource.pages.edit-category' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\EditCategory',
    'app.filament.resources.category-resource.pages.list-categories' => 'App\\Filament\\Resources\\CategoryResource\\Pages\\ListCategories',
    'app.filament.resources.contact-resource.pages.create-contact' => 'App\\Filament\\Resources\\ContactResource\\Pages\\CreateContact',
    'app.filament.resources.contact-resource.pages.edit-contact' => 'App\\Filament\\Resources\\ContactResource\\Pages\\EditContact',
    'app.filament.resources.contact-resource.pages.list-contacts' => 'App\\Filament\\Resources\\ContactResource\\Pages\\ListContacts',
    'app.filament.resources.gallery-resource.pages.create-gallery' => 'App\\Filament\\Resources\\GalleryResource\\Pages\\CreateGallery',
    'app.filament.resources.gallery-resource.pages.edit-gallery' => 'App\\Filament\\Resources\\GalleryResource\\Pages\\EditGallery',
    'app.filament.resources.gallery-resource.pages.list-galleries' => 'App\\Filament\\Resources\\GalleryResource\\Pages\\ListGalleries',
    'app.filament.resources.page-resource.pages.create-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\CreatePage',
    'app.filament.resources.page-resource.pages.edit-page' => 'App\\Filament\\Resources\\PageResource\\Pages\\EditPage',
    'app.filament.resources.page-resource.pages.list-pages' => 'App\\Filament\\Resources\\PageResource\\Pages\\ListPages',
    'app.filament.resources.post-resource.pages.create-post' => 'App\\Filament\\Resources\\PostResource\\Pages\\CreatePost',
    'app.filament.resources.post-resource.pages.edit-post' => 'App\\Filament\\Resources\\PostResource\\Pages\\EditPost',
    'app.filament.resources.post-resource.pages.list-posts' => 'App\\Filament\\Resources\\PostResource\\Pages\\ListPosts',
    'app.filament.resources.service-resource.pages.create-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\CreateService',
    'app.filament.resources.service-resource.pages.edit-service' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\EditService',
    'app.filament.resources.service-resource.pages.list-services' => 'App\\Filament\\Resources\\ServiceResource\\Pages\\ListServices',
    'app.filament.resources.setting-resource.pages.create-setting' => 'App\\Filament\\Resources\\SettingResource\\Pages\\CreateSetting',
    'app.filament.resources.setting-resource.pages.edit-setting' => 'App\\Filament\\Resources\\SettingResource\\Pages\\EditSetting',
    'app.filament.resources.setting-resource.pages.list-settings' => 'App\\Filament\\Resources\\SettingResource\\Pages\\ListSettings',
    'app.filament.resources.team-resource.pages.create-team' => 'App\\Filament\\Resources\\TeamResource\\Pages\\CreateTeam',
    'app.filament.resources.team-resource.pages.edit-team' => 'App\\Filament\\Resources\\TeamResource\\Pages\\EditTeam',
    'app.filament.resources.team-resource.pages.list-teams' => 'App\\Filament\\Resources\\TeamResource\\Pages\\ListTeams',
    'app.filament.resources.testimonial-resource.pages.create-testimonial' => 'App\\Filament\\Resources\\TestimonialResource\\Pages\\CreateTestimonial',
    'app.filament.resources.testimonial-resource.pages.edit-testimonial' => 'App\\Filament\\Resources\\TestimonialResource\\Pages\\EditTestimonial',
    'app.filament.resources.testimonial-resource.pages.list-testimonials' => 'App\\Filament\\Resources\\TestimonialResource\\Pages\\ListTestimonials',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'D:\\Lading page profile\\landing-page-kantor\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\CategoryResource.php' => 'App\\Filament\\Resources\\CategoryResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\ContactResource.php' => 'App\\Filament\\Resources\\ContactResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\GalleryResource.php' => 'App\\Filament\\Resources\\GalleryResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\PageResource.php' => 'App\\Filament\\Resources\\PageResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\PostResource.php' => 'App\\Filament\\Resources\\PostResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\ServiceResource.php' => 'App\\Filament\\Resources\\ServiceResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\SettingResource.php' => 'App\\Filament\\Resources\\SettingResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\TeamResource.php' => 'App\\Filament\\Resources\\TeamResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\TestimonialResource.php' => 'App\\Filament\\Resources\\TestimonialResource',
    'D:\\Lading page profile\\landing-page-kantor\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'D:\\Lading page profile\\landing-page-kantor\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'D:\\Lading page profile\\landing-page-kantor\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);