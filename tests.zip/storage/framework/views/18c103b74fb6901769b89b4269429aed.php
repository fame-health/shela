
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title><?php echo e($metaTitle ?? 'Blog - Lentera Remaja'); ?></title>
  <meta name="description" content="<?php echo e($metaDescription ?? 'Daftar artikel kesehatan dan edukasi terbaru dari Lentera Remaja'); ?>" />
  <meta name="keywords" content="<?php echo e($metaKeywords ?? 'blog, artikel, kesehatan, edukasi, informasi kesehatan'); ?>" />
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />
  <style>
           .mobile-menu {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .mobile-menu.active {
            transform: translateX(0);
        }
        .hamburger {
            transition: all 0.3s ease;
        }
        .hamburger.active .line1 {
            transform: rotate(-45deg) translate(-5px, 6px);
        }
        .hamburger.active .line2 {
            opacity: 0;
        }
        .hamburger.active .line3 {
            transform: rotate(45deg) translate(-5px, -6px);
        }
    .hero-gradient {
      background: linear-gradient(135deg, rgba(236, 72, 153, 0.1) 0%, rgba(236, 72, 153, 0.05) 100%);
    }
    .card-hover:hover {
      transform: translateY(-5px);
      box-shadow: 0 20px 25px -5px rgba(236, 72, 153, 0.1), 0 10px 10px -5px rgba(236, 72, 153, 0.04);
    }
    .smooth-transition {
      transition: all 0.3s ease;
    }
  </style>
</head>
<body class="bg-gray-100 text-gray-800">
  <!-- Header -->
  <header class="fixed top-0 w-full z-40 bg-white shadow">
    <div class="container mx-auto px-4 py-4 flex justify-between items-center">
      <div class="text-2xl font-bold text-pink-500">
        <a href="/">Lentera<span class="text-gray-700">Remaja</span></a>
      </div>
      <!-- Desktop Menu -->
      <nav class="hidden md:flex space-x-8">
        <a href="/" class="text-gray-700 hover:text-pink-500 transition-colors font-medium">Home</a>
        <a href="#education" class="text-gray-700 hover:text-pink-500 transition-colors font-medium">Edukasi</a>
        <a href="#solutions" class="text-gray-700 hover:text-pink-500 transition-colors font-medium">Solusi</a>
        <a href="#faq" class="text-gray-700 hover:text-pink-500 transition-colors font-medium">FAQ</a>
        <a href="#contact" class="text-gray-700 hover:text-pink-500 transition-colors font-medium">Kontak</a>
        <a href="/blog" class="text-gray-700 hover:text-pink-500 transition-colors font-medium">Blog</a>

      </nav>
      <!-- Desktop CTA Button -->
      <button class="hidden md:block bg-pink-500 text-white px-6 py-2 rounded-full hover:bg-pink-600 transition-colors">
        Konsultasi Gratis
      </button>
      <!-- Mobile Menu Button -->
      <button class="md:hidden hamburger" id="mobile-menu-btn">
        <div class="w-6 h-0.5 bg-gray-700 mb-1 transition-all line1"></div>
        <div class="w-6 h-0.5 bg-gray-700 mb-1 transition-all line2"></div>
        <div class="w-6 h-0.5 bg-gray-700 transition-all line3"></div>
      </button>
    </div>
    <!-- Mobile Menu Overlay -->
    <div class="md:hidden mobile-menu fixed top-0 right-0 w-full h-screen bg-white z-50" id="mobile-menu">
      <div class="p-6">
        <!-- Mobile Menu Header -->
        <div class="flex justify-between items-center mb-8">
          <div class="text-2xl font-bold text-pink-500">
            Lentera<span class="text-gray-700">Remaja</span>
          </div>
          <button class="text-gray-700 text-2xl" id="close-menu">
            <i class="fas fa-times"></i>
          </button>
        </div>
        <!-- Mobile Menu Items -->
        <ul class="space-y-6">
          <li><a href="/" class="block text-xl text-gray-700 hover:text-pink-500 transition-colors py-2 border-b border-gray-100">Home</a></li>
          <li><a href="#education" class="block text-xl text-gray-700 hover:text-pink-500 transition-colors py-2 border-b border-gray-100">Edukasi</a></li>
          <li><a href="#solutions" class="block text-xl text-gray-700 hover:text-pink-500 transition-colors py-2 border-b border-gray-100">Solusi</a></li>
          <li><a href="#faq" class="block text-xl text-gray-700 hover:text-pink-500 transition-colors py-2 border-b border-gray-100">FAQ</a></li>
          <li><a href="#contact" class="block text-xl text-gray-700 hover:text-pink-500 transition-colors py-2 border-b border-gray-100">Kontak</a></li>
          <li><a href="/blogt" class="block text-xl text-gray-700 hover:text-pink-500 transition-colors py-2 border-b border-gray-100">Blog</a></li>

        </ul>
        <!-- Mobile Contact Info -->
        <div class="mt-8 p-4 bg-gray-50 rounded-2xl">
          <h3 class="font-semibold text-gray-800 mb-4">Hubungi Kami</h3>
          <div class="space-y-3">
            <div class="flex items-center text-gray-600">
              <i class="fas fa-phone text-pink-500 mr-3"></i>
              <span>+62-8226-2559-692</span>
            </div>
            <div class="flex items-center text-gray-600">
              <i class="fas fa-envelope text-pink-500 mr-3"></i>
              <span>striagraini@gmail.com</span>
            </div>
          </div>
        </div>
        <!-- Mobile CTA Button -->
        <button class="w-full mt-6 bg-pink-500 text-white py-4 rounded-full font-semibold hover:bg-pink-600 transition-colors">
          Konsultasi Gratis
        </button>
      </div>
    </div>
  </header>

  <!-- Main Content -->
  <main class="pt-24">
    <!-- Hero Section -->
    <section class="hero-gradient py-16">
      <div class="container mx-auto px-4 text-center">
        <h1 class="text-4xl md:text-5xl font-bold text-gray-800 mb-4 animate__animated animate__fadeInDown">
          Artikel <span class="text-pink-500">Kesehatan</span> Terbaru
        </h1>
        <p class="text-xl text-gray-600 mb-8 animate__animated animate__fadeInUp">
          Temukan informasi kesehatan terpercaya dan tips hidup sehat
        </p>
      </div>
    </section>

    <!-- Blog Articles -->
<!-- Blog Articles -->
<section class="py-16">
  <div class="container mx-auto px-4">
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="bg-white rounded-2xl overflow-hidden shadow-lg card-hover smooth-transition animate__animated animate__fadeInUp">
          <?php if($post->featured_image): ?>
            <div class="relative">
              <img
                src="<?php echo e($post->featured_image); ?>"
                alt="<?php echo e($post->title); ?>"
                class="w-full h-48 object-cover"
              >
              <div class="absolute top-4 left-4">
                <span class="bg-pink-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                  <?php echo e($post->category->name ?? 'Kesehatan'); ?>

                </span>
              </div>
            </div>
          <?php endif; ?>

          <div class="p-6">
            <div class="flex items-center text-sm text-gray-500 mb-3">
              <i class="fas fa-calendar text-pink-500 mr-2"></i>
              <?php echo e(\Carbon\Carbon::parse($post->published_at)->format('d M Y')); ?>

            </div>

            <h2 class="text-xl font-bold text-gray-800 mb-3 hover:text-pink-500 transition-colors">
              <a href="<?php echo e(route('blog.show', $post->slug)); ?>"><?php echo e($post->title); ?></a>
            </h2>

            <p class="text-gray-600 mb-4 leading-relaxed">
              <?php echo e(Str::limit($post->excerpt, 120)); ?>

            </p>

            <div class="flex justify-between items-center">
              <a href="<?php echo e(route('blog.show', $post->slug)); ?>"
                 class="inline-flex items-center text-pink-500 hover:text-pink-600 font-medium transition-colors">
                Baca Selengkapnya
                <i class="fas fa-arrow-right ml-2"></i>
              </a>
              <div class="flex items-center text-sm text-gray-400">
                <i class="fas fa-eye mr-1"></i>
                <span><?php echo e($post->views ?? 0); ?></span>
              </div>
            </div>
          </div>
        </article>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-span-full text-center py-16">
          <div class="text-gray-400 mb-4">
            <i class="fas fa-newspaper text-6xl"></i>
          </div>
          <h3 class="text-2xl font-semibold text-gray-600 mb-2">Belum Ada Artikel</h3>
          <p class="text-gray-500">Artikel kesehatan akan segera hadir untuk Anda.</p>
        </div>
      <?php endif; ?>
    </div>

    <!-- Pagination -->
    <?php if(method_exists($posts, 'links')): ?>
      <div class="mt-12 flex justify-center">
        <?php echo e($posts->links()); ?>

      </div>
    <?php endif; ?>
  </div>
</section>


    <!-- Newsletter Section -->
    <section class="bg-pink-50 py-16">
      <div class="container mx-auto px-4 text-center">
        <h2 class="text-3xl font-bold text-gray-800 mb-4">
          Dapatkan <span class="text-pink-500">Tips Kesehatan</span> Terbaru
        </h2>
        <p class="text-gray-600 mb-8 max-w-2xl mx-auto">
          Berlangganan newsletter kami untuk mendapatkan artikel kesehatan, tips hidup sehat, dan informasi medis terpercaya langsung di email Anda.
        </p>
        <form class="max-w-md mx-auto flex gap-4">
          <input type="email"
                 placeholder="Masukkan email Anda"
                 class="flex-1 px-4 py-3 rounded-full border border-gray-300 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-200">
          <button type="submit"
                  class="bg-pink-500 text-white px-8 py-3 rounded-full hover:bg-pink-600 transition-colors font-medium">
            Berlangganan
          </button>
        </form>
      </div>
    </section>
  </main>




  <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH D:\Lading page profile\landing-page-kantor\resources\views/blog/index.blade.php ENDPATH**/ ?>